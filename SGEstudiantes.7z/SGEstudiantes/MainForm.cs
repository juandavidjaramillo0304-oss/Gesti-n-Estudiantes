﻿using SGEstudiantes.Forms;
using System;
using System.Windows.Forms;

namespace SGEstudiantes
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnGestionEstudiantes_Click(object sender, EventArgs e)
        {
            var frm = new FormStudents();
            frm.ShowDialog();
        }
    }
}

