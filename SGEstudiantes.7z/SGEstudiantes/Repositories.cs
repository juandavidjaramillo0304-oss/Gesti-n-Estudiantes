﻿using SGEstudiantes.Models;
using SGEstudiantes.Models.SGEstudiantes.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SGEstudiantes.Repositories
{
    public class StudentRepository
    {
        private readonly List<Student> _data = new List<Student>();
        private int _nextId = 1;

        public StudentRepository()
        {
            SeedSampleData();
        }

        public int Add(Student s)
        {
            s.StudentId = _nextId++;
            _data.Add(s);
            return s.StudentId;
        }

        public List<Student> GetAll()
        {
            return _data.ToList();
        }

        public Student GetById(int id)
        {
            return _data.FirstOrDefault(x => x.StudentId == id);
        }

        public bool Update(Student s)
        {
            var ex = GetById(s.StudentId);
            if (ex == null)
                return false;

            ex.Nombre = s.Nombre;
            ex.Identificacion = s.Identificacion;
            ex.Carrera = s.Carrera;
            ex.FechaIngreso = s.FechaIngreso;

            if (ex is Undergrad u1 && s is Undergrad u2)
                u1.Semestre = u2.Semestre;

            if (ex is Postgrad p1 && s is Postgrad p2)
                p1.Programa = p2.Programa;

            return true;
        }

        public bool Delete(int id)
        {
            var s = GetById(id);
            if (s == null) return false;
            _data.Remove(s);
            return true;
        }

        private void SeedSampleData()
        {
            Add(new Undergrad
            {
                Nombre = "Laura Castaño",
                Identificacion = "112233",
                Carrera = "Ingeniería",
                FechaIngreso = new DateTime(2022, 2, 1),
                Semestre = 4
            });

            Add(new Postgrad
            {
                Nombre = "María Ruiz",
                Identificacion = "996655",
                Carrera = "MBA",
                FechaIngreso = new DateTime(2023, 3, 10),
                Programa = "Finanzas"
            });
        }
    }
}
