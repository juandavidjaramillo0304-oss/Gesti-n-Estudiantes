﻿using System;

namespace SGEstudiantes.Models
{
    namespace SGEstudiantes.Models
    {
        public abstract class Student
        {
            public int StudentId { get; set; }
            public string Nombre { get; set; }
            public string Identificacion { get; set; }
            public string Carrera { get; set; }
            public DateTime FechaIngreso { get; set; }
            public abstract string Tipo { get; }
        }
    }


    namespace SGEstudiantes.Models
    {
        public class Undergrad : Student
        {
            public int Semestre { get; set; }
            public override string Tipo => "Pregrado";
        }
    }




    namespace SGEstudiantes.Models
    {
        public class Postgrad : Student
        {
            public string Programa { get; set; }
            public override string Tipo => "Postgrado";
        }
    }
}