﻿using SGEstudiantes.Models;
using SGEstudiantes.Models.SGEstudiantes.Models;
using System;

namespace SGEstudiantes.Factories
{
    public class StudentFactory
    {
        public Student Crear(string tipo)
        {
            switch (tipo)
            {
                case "Pregrado":
                    return new Undergrad();
                case "Postgrado":
                    return new Postgrad();
                default:
                    throw new ArgumentException("Tipo inválido");
            }
        }
    }
}
