﻿using SGEstudiantes.Factories;
using SGEstudiantes.Models;
using SGEstudiantes.Models.SGEstudiantes.Models;
using SGEstudiantes.Repositories;
using System;
using System.Windows.Forms;

namespace SGEstudiantes.Forms
{
    public partial class FormStudentDetails : Form
    {
        private readonly StudentRepository _repo;
        private readonly StudentFactory _factory;
        private Student _editing;

        public FormStudentDetails(StudentRepository repo, StudentFactory factory, Student editing)
        {
            InitializeComponent();
            _repo = repo;
            _factory = factory;
            _editing = editing;

            cboTipo.Items.Add("Pregrado");
            cboTipo.Items.Add("Postgrado");

            if (_editing != null)
                LoadData();
        }

        private void LoadData()
        {
            txtNombre.Text = _editing.Nombre;
            txtIdentificacion.Text = _editing.Identificacion;
            txtCarrera.Text = _editing.Carrera;
            dtpFechaIngreso.Value = _editing.FechaIngreso;
            cboTipo.SelectedItem = _editing.Tipo;

            if (_editing is Undergrad u)
                txtExtra.Text = u.Semestre.ToString();

            if (_editing is Postgrad p)
                txtExtra.Text = p.Programa;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (cboTipo.SelectedItem == null)
            {
                MessageBox.Show("Seleccione tipo.");
                return;
            }

            string tipo = cboTipo.SelectedItem.ToString();

            if (_editing == null)
            {
                var s = _factory.Crear(tipo);
                s.Nombre = txtNombre.Text.Trim();
                s.Identificacion = txtIdentificacion.Text.Trim();
                s.Carrera = txtCarrera.Text.Trim();
                s.FechaIngreso = dtpFechaIngreso.Value;

                if (s is Undergrad u)
                    u.Semestre = int.Parse(txtExtra.Text);

                if (s is Postgrad p)
                    p.Programa = txtExtra.Text;

                _repo.Add(s);
            }
            else
            {
                _editing.Nombre = txtNombre.Text.Trim();
                _editing.Identificacion = txtIdentificacion.Text.Trim();
                _editing.Carrera = txtCarrera.Text.Trim();
                _editing.FechaIngreso = dtpFechaIngreso.Value;

                if (_editing is Undergrad u)
                    u.Semestre = int.Parse(txtExtra.Text);

                if (_editing is Postgrad p)
                    p.Programa = txtExtra.Text;

                _repo.Update(_editing);
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
