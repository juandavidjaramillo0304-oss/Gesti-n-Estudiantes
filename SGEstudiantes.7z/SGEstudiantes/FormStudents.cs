﻿using SGEstudiantes.Factories;
using SGEstudiantes.Models;
using SGEstudiantes.Models.SGEstudiantes.Models;
using SGEstudiantes.Repositories;
using System;
using System.Linq;
using System.Windows.Forms;

namespace SGEstudiantes.Forms
{
    public partial class FormStudents : Form
    {
        private readonly StudentRepository _repo;
        private readonly StudentFactory _factory;

        public FormStudents()
        {
            InitializeComponent();

            _repo = new StudentRepository();
            _factory = new StudentFactory();

            LoadStudents();
        }

        private void LoadStudents()
        {
            var list = _repo.GetAll()
                .Select(s => new
                {
                    s.StudentId,
                    s.Nombre,
                    s.Identificacion,
                    s.Carrera,
                    Tipo = s.Tipo,
                    FechaIngreso = s.FechaIngreso.ToShortDateString(),
                    Extra = s is Undergrad u ? $"Sem: {u.Semestre}" :
                           s is Postgrad p ? $"Prog: {p.Programa}" : ""
                })
                .ToList();

            dgvStudents.DataSource = null;
            dgvStudents.DataSource = list;
            dgvStudents.Columns["StudentId"].Visible = false;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            var frm = new FormStudentDetails(_repo, _factory, null);

            if (frm.ShowDialog() == DialogResult.OK)
                LoadStudents();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvStudents.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un estudiante.");
                return;
            }

            int id = (int)dgvStudents.CurrentRow.Cells["StudentId"].Value;

            var student = _repo.GetById(id);

            var frm = new FormStudentDetails(_repo, _factory, student);
            if (frm.ShowDialog() == DialogResult.OK)
                LoadStudents();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvStudents.CurrentRow == null) return;

            int id = (int)dgvStudents.CurrentRow.Cells["StudentId"].Value;

            if (MessageBox.Show("¿Eliminar?", "Confirmar",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _repo.Delete(id);
                LoadStudents();
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string term = txtBuscar.Text.Trim().ToLower();

            var filtered = _repo.GetAll()
                .Where(s => s.Nombre.ToLower().Contains(term) ||
                            s.Identificacion.ToLower().Contains(term) ||
                            s.Carrera.ToLower().Contains(term))
                .Select(s => new
                {
                    s.StudentId,
                    s.Nombre,
                    s.Identificacion,
                    s.Carrera,
                    Tipo = s.Tipo,
                    FechaIngreso = s.FechaIngreso.ToShortDateString(),
                    Extra = s is Undergrad u ? $"Sem: {u.Semestre}" :
                           s is Postgrad p ? $"Prog: {p.Programa}" : ""
                })
                .ToList();

            dgvStudents.DataSource = filtered;
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            LoadStudents();
        }
    }
}

