﻿namespace SGEstudiantes
{
    partial class MainForm
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnGestionEstudiantes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(142, 172);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(170, 13);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Sistema De Gestión De Estudiante";
            // 
            // btnGestionEstudiantes
            // 
            this.btnGestionEstudiantes.Location = new System.Drawing.Point(175, 203);
            this.btnGestionEstudiantes.Name = "btnGestionEstudiantes";
            this.btnGestionEstudiantes.Size = new System.Drawing.Size(99, 45);
            this.btnGestionEstudiantes.TabIndex = 1;
            this.btnGestionEstudiantes.Text = "Gestión Estudiantes";
            this.btnGestionEstudiantes.UseVisualStyleBackColor = true;
            this.btnGestionEstudiantes.Click += new System.EventHandler(this.btnGestionEstudiantes_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 450);
            this.Controls.Add(this.btnGestionEstudiantes);
            this.Controls.Add(this.lblTitulo);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnGestionEstudiantes;
    }
}

